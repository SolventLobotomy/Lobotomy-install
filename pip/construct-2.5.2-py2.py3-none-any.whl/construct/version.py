version = (2, 5, 2)
version_string = "2.5.2"
release_date = "2014.04.28"
