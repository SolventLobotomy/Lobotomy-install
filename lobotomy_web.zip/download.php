<?php
require('includes/setup.php');
if (!isset($_COOKIE[$config->cookie_name]) || !$auth->checkSession($_COOKIE[$config->cookie_name])) {
    header('Location: login.php');
    exit();
} else {
    $user = $auth->getUser($auth->getSessionUID($_COOKIE[$config->cookie_name]));
//Array (4)
//email
//password
//isactive
//uid
}
$lobotomy = new Lobotomy($dbh, $user['uid']);

if (!$lobotomy->selection['imageid']) {
    header('location: index.php');
    exit;
}
$image = $lobotomy->getImageDetails($lobotomy->selection['imageid']);
$settings = $lobotomy->getImageSettings($image['dbase']);
$file = $settings['filepath'].'-mactime.csv';

if (file_exists($file)) {
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename='.basename($file));
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file));
    ob_clean();
    flush();
    readfile($file);
    exit;
}
?>