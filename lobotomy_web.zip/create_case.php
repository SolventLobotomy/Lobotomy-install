<?php
require('includes/setup.php');
if (!isset($_COOKIE[$config->cookie_name]) || !$auth->checkSession($_COOKIE[$config->cookie_name])) {
    header('Location: login.php');
    exit();
} else {
    $user = $auth->getUser($auth->getSessionUID($_COOKIE[$config->cookie_name]));
}
$lobotomy = new Lobotomy($dbh, $user['uid']);
$smarty = new Template();
$smarty->assign('page', 'Create a new case');
$smarty->assign('user', $user);
$user_alias = $lobotomy->getAlias('user', $user['uid']);
if ($user_alias) {
    $smarty->assign('user_alias', $user_alias);
}

$smarty->assign('selection', $lobotomy->selection);
if ($lobotomy->selection['imageid']) {
    $imageinfo = $lobotomy->getImageDetails($lobotomy->selection['imageid']);
    $smarty->assign('plugins', $lobotomy->getPluginNames($lobotomy->selection['dbase']));
}
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if (isset($_POST['user_alias'])) {
        $alias = trim($_POST['user_alias']);
        if (empty($alias)) {
            $removeAlias = $dbh->prepare("DELETE FROM aliases WHERE type='user' AND type_id=?");
            $removeAlias->execute(array($user['uid']));
        } else {
            $updateUseralias = $dbh->prepare("INSERT INTO aliases (type, type_id, alias) VALUES ('user', ?, ?) ON DUPLICATE KEY UPDATE alias=?");
            $updateUseralias->execute(array($user['uid'], $alias, $alias));
        }
    } elseif (isset($_POST['name']) && isset($_POST['description'])) {
        $desc = trim($_POST['description']);
        $name = trim($_POST['name']);
        if (!empty($name) && $name != '') {
            $owner = isset($_POST['public']) ? 0 : $user['uid'];
            $addCase = $dbh->prepare("INSERT INTO cases (name, description, creator, added, ownerid) VALUES (?, ?, ?, NOW(), ?)");
            $addCase->execute(array($name, $desc, $user['uid'], $owner));
            header('Location: index.php');
            exit;
        }
    }
    header('location: create_case.php');
}
$smarty->display('create_case.tpl');
?>