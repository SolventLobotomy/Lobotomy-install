<?php

require('includes/setup.php');
if (!isset($_COOKIE[$config->cookie_name]) || !$auth->checkSession($_COOKIE[$config->cookie_name])) {
    header('Location: login.php');
    exit();
} else {
    $user = $auth->getUser($auth->getSessionUID($_COOKIE[$config->cookie_name]));
}
$lobotomy = new Lobotomy($dbh, $user['uid']);
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if (isset($_POST['user_alias'])) {
        $alias = trim($_POST['user_alias']);
        if (empty($alias)) {
            $removeAlias = $dbh->prepare("DELETE FROM aliases WHERE type='user' AND type_id=?");
            $removeAlias->execute(array($user['uid']));
        } else {
            $updateUseralias = $dbh->prepare("INSERT INTO aliases (type, type_id, alias) VALUES ('user', ?, ?) ON DUPLICATE KEY UPDATE alias=?");
            $updateUseralias->execute(array($user['uid'], $alias, $alias));
        }
    }
    header('location: queue.php');
}
$smarty = new Template();
$smarty->assign('page', 'Queue');
$smarty->assign('user', $user);
$user_alias = $lobotomy->getAlias('user', $user['uid']);
if ($user_alias) {
    $smarty->assign('user_alias', $user_alias);
}

$smarty->assign('selection', $lobotomy->selection);
$smarty->assign('caseinfo', $lobotomy->getCaseDetails($lobotomy->selection['caseid']));
$imageinfo = $lobotomy->getImageDetails($lobotomy->selection['imageid']);
$smarty->assign('imageinfo', $imageinfo);
if ($lobotomy->selection['imageid']) {
    $imageinfo = $lobotomy->getImageDetails($lobotomy->selection['imageid']);
    $smarty->assign('plugins', $lobotomy->getPluginNames($imageinfo['dbase']));
    $smarty->assign('queue', $lobotomy->getQueue());
}
$smarty->display('queue.tpl');
?>