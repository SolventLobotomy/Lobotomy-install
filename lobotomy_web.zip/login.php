<?php
require('includes/setup.php');
$smarty = new Template();
$smarty->assign('page', 'Login');

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $pass = true;
    $err = array();
    if (!isset($_POST['email'])) {
        $pass = false;
        $err[] = 'Enter your e-mail address';
    }
    if (!isset($_POST['password']) || $_POST['password'] == '') {
        $pass = false;
        $err[] = 'Enter your password';
    }
    if ($pass) {
        $email = $_POST["email"];
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $pass = false;
            $err[] = 'Invalid email format';
        }
    }
    if ($pass) {
        if (isset($_POST['remember']) && $_POST['remember'] == "1") {
            $remember = true;
        }
        else {
            $remember = false;
        }
    }
    if (!$pass) {
        $smarty->assign('errors', $err);
    }
    else {
        $rtn = $auth->login($_POST['email'], $_POST['password'], $remember);
        if (!$rtn['error']) {
            setcookie($config->cookie_name, $rtn['hash'], $rtn['expire'], $config->cookie_path, $config->cookie_domain, $config->cookie_secure, $config->cookie_http);
            header('Location: index.php');
        }
        $smarty->assign('rtn', $rtn);
    }
}

$smarty->display('login.tpl');
?>