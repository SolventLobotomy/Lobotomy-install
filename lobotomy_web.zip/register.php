<?php
require('includes/setup.php');
$smarty = new Template();
$smarty->assign('page', 'Register');

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $pass = true;
    $err = array();
    if (!isset($_POST['email'])) {
        $pass = false;
        $err[] = 'Enter your e-mail address';
    }
    if (!isset($_POST['firstpass']) || $_POST['firstpass'] == '') {
        $pass = false;
        $err[] = 'Enter a password';
    }
    if (!isset($_POST['secondpass']) || $_POST['secondpass'] == '') {
        $pass = false;
        $err[] = 'Re-type your password';
    }
    if ($pass) {
        $email = $_POST["email"];
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $pass = false;
            $err[] = 'Invalid email format';
        }
    }
    if ($pass) {
        if ($_POST['firstpass'] != $_POST['secondpass']) {
            $pass = false;
            $err[] = 'Passwords do not match';
        }
    }
    if ($pass) {
        $password = $_POST['firstpass'];
        if(strlen($password) < 8) {
            $pass = false;
            $err[] = 'Password is too short';
        }
        if(strlen($password) > 32) {
            $pass = false;
            $err[] = 'Password is too long';
        }
        if(!preg_match("#[0-9]+#", $password)) {
            $pass = false;
            $err[] = 'Password does not contain a number';
        }
        if(!preg_match("#[a-z]+#", $password)) {
            $pass = false;
            $err[] = 'Password does not contain a lowercase character';
        }
        if(!preg_match("#[A-Z]+#", $password)) {
            $pass = false;
            $err[] = 'Password does not contain an uppercase character';
        }
    }
    if (!$pass) {
        $smarty->assign('errors', $err);
    }
    else {
        $rtn = $auth->register($_POST['email'], $_POST['firstpass'], $_POST['secondpass']);
        $smarty->assign('rtn', $rtn);
    }
}

$smarty->display('registration.tpl');
?>