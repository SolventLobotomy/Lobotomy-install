<?php
require('includes/setup.php');
$smarty = new Template();
$smarty->assign('page', 'Logout');

if (isset($_COOKIE[$config->cookie_name])) {
    $auth->logout($_COOKIE[$config->cookie_name]);
    setcookie($config->cookie_name, 0, 0, $config->cookie_path, $config->cookie_domain, $config->cookie_secure, $config->cookie_http);
    unset($_COOKIE[$config->cookie_name]);
    header('Location: index.php');
}
?>