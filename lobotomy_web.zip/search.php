<?php

require('includes/setup.php');
ini_set('memory_limit', '-1');
if (!isset($_COOKIE[$config->cookie_name]) || !$auth->checkSession($_COOKIE[$config->cookie_name])) {
    header('Location: login.php');
    exit();
} else {
    $user = $auth->getUser($auth->getSessionUID($_COOKIE[$config->cookie_name]));
}
$lobotomy = new Lobotomy($dbh, $user['uid']);
$smarty = new Template();
$smarty->assign('page', 'Search');
$smarty->assign('user', $user);
$user_alias = $lobotomy->getAlias('user', $user['uid']);
if ($user_alias) {
    $smarty->assign('user_alias', $user_alias);
}
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if (isset($_POST['user_alias'])) {
        $alias = trim($_POST['user_alias']);
        if (empty($alias)) {
            $removeAlias = $dbh->prepare("DELETE FROM aliases WHERE type='user' AND type_id=?");
            $removeAlias->execute(array($user['uid']));
        } else {
            $updateUseralias = $dbh->prepare("INSERT INTO aliases (type, type_id, alias) VALUES ('user', ?, ?) ON DUPLICATE KEY UPDATE alias=?");
            $updateUseralias->execute(array($user['uid'], $alias, $alias));
        }
        header('location: search.php');
    }
    if (isset($_POST['image_string'])) {
        $string = trim($_POST['image_string']);
        if (!empty($string)) {
            $smarty->assign('search_string', $string);
            $smarty->assign('search_results', $lobotomy->searchImageStr($string));
            $smarty->assign('search_method', 'string');
        }
    }
    if (isset($_POST['image_pid'])) {
        $string = trim($_POST['image_pid']);
        if (!empty($string)) {
            $smarty->assign('search_string', $string);
            $smarty->assign('search_results', $lobotomy->searchImagePid($string));
            $smarty->assign('search_method', 'PID');
        }
    }
    if (isset($_POST['strings_string'])) {
        $string = trim($_POST['strings_string']);
        if (!empty($string)) {
            $smarty->assign('search_string', $string);
            $smarty->assign('search_results', $lobotomy->searchStringsStr($string));
            $smarty->assign('search_method', 'string (in strings)');
        }
    }
}

$smarty->assign('selection', $lobotomy->selection);
if ($lobotomy->selection['imageid']) {
    $imageinfo = $lobotomy->getImageDetails($lobotomy->selection['imageid']);
    $smarty->assign('plugins', $lobotomy->getPluginNames($imageinfo['dbase']));
}

$smarty->assign('caseinfo', $lobotomy->getCaseDetails($lobotomy->selection['caseid']));
$smarty->assign('imageinfo', $imageinfo);
$smarty->display('search.tpl');
?>