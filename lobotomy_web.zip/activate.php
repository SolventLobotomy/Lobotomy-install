<?php
require('includes/setup.php');
$smarty = new Template();
$smarty->assign('page', 'Activate Account');

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $pass = true;
    $err = array();
    if (!isset($_POST['code']) || $_POST['code'] == '') {
        $pass = false;
        $err[] = 'Enter your activation code';
    }
    if (!$pass) {
        $smarty->assign('errors', $err);
    }
    else {
        $rtn = $auth->activate($_POST['code']);
        $smarty->assign('rtn', $rtn);
    }
}

$smarty->display('activate.tpl');
?>