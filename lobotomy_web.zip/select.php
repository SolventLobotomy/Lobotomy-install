<?php

require('includes/setup.php');
if (!isset($_COOKIE[$config->cookie_name]) || !$auth->checkSession($_COOKIE[$config->cookie_name])) {
    header('Location: login.php');
    exit();
} else {
    $user = $auth->getUser($auth->getSessionUID($_COOKIE[$config->cookie_name]));
}
$lobotomy = new Lobotomy($dbh, $user['uid']);
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $actions = array('mark', 'unmark');
    if (isset($_POST['id'])) {
        $i = intval($_POST['id']);
        if (!is_int($i)) {
            return false;
        }
	list($dbase, $plugin) = explode('.', $_POST['plugin']);
        if (!$lobotomy->isValidPlugin($dbase, $plugin)) {
            return false;
        }
        if (!in_array($_POST['action'], $actions)) {
            return false;
        }
        if ($_POST['action'] == "mark") {
            $q = $dbh->prepare("INSERT INTO ".$dbase.".`preferences` (plugin, row_id, action) VALUES ('" . $plugin . "', " . $i . ", 'mark')");
            $q->execute();
        } elseif ($_POST['action'] == "unmark") {
            $q = $dbh->prepare("DELETE FROM ".$dbase.".`preferences` WHERE plugin='" . $plugin . "' AND row_id=" . $i);
            $q->execute();
        } else {
            return false;
        }
    }
}
?>
