<?php

require('includes/setup.php');
if (!isset($_COOKIE[$config->cookie_name]) || !$auth->checkSession($_COOKIE[$config->cookie_name])) {
    header('Location: login.php');
    exit();
    //$user = array(
    //    'email' => 'iscripters@gmail.com',
    //    'password' => '',
    //    'isactive' => 1,
    //    'uid' => 1
    //);
} else {
    $user = $auth->getUser($auth->getSessionUID($_COOKIE[$config->cookie_name]));
//Array (4)
//email
//password
//isactive
//uid
}
$smarty = new Template();
$smarty->assign('page', 'Home');
$smarty->assign('user', $user);
$lobotomy = new Lobotomy($dbh, $user['uid']);

$user_alias = $lobotomy->getAlias('user', $user['uid']);
if ($user_alias) {
    $smarty->assign('user_alias', $user_alias);
}

$smarty->assign('selection', $lobotomy->selection);
if ($lobotomy->selection['caseid'] == 0 || $lobotomy->canAccessCase($user['uid'], $lobotomy->selection['caseid']) == false) {
    $smarty->assign('cases', $lobotomy->getCases($user['uid']));
    $smarty->display('case_list.tpl');
} else {
    if ($lobotomy->selection['imageid'] == 0) {
        $smarty->assign('caseinfo', $lobotomy->getCaseDetails($lobotomy->selection['caseid']));
        $smarty->assign('images', $lobotomy->getImages($lobotomy->selection['caseid']));
        $smarty->assign('isOwner', $lobotomy->isCaseOwner($user['uid'], $lobotomy->selection['caseid']));
        $smarty->assign('perms', $lobotomy->getCaseAccess());
        $smarty->display('image_list.tpl');
    } else {
        $smarty->assign('caseinfo', $lobotomy->getCaseDetails($lobotomy->selection['caseid']));
        $imageinfo = $lobotomy->getImageDetails($lobotomy->selection['imageid']);
        $smarty->assign('isOwner', $lobotomy->isCaseOwner($user['uid'], $lobotomy->selection['caseid']));
        $smarty->assign('imageinfo', $imageinfo);
        $smarty->assign('imagesettings', $lobotomy->getImageSettings($imageinfo['dbase']));
        $alias = $lobotomy->getAlias('image', $lobotomy->selection['imageid']);
        if ($alias) {
            $smarty->assign('image_alias', $alias);
        }
        if ($_SERVER['REQUEST_METHOD'] == "POST") {
            if (isset($_POST['description'])) {
                $desc = trim($_POST['description']);
                $updateDescription = $dbh->prepare("UPDATE " . $imageinfo['dbase'] . ".settings SET description=?");
                $updateDescription->execute(array($desc));
            } elseif (isset($_POST['profile'])) {
                if (in_array($_POST['profile'], $lobotomy->supported_profiles)) {
                    $updateProfile = $dbh->prepare("UPDATE " . $imageinfo['dbase'] . ".settings SET profile=?");
                    $updateProfile->execute(array($_POST['profile']));
                }
            } elseif (isset($_POST['alias'])) {
                $alias = trim($_POST['alias']);
                if (empty($alias)) {
                    $removeAlias = $dbh->prepare("DELETE FROM aliases WHERE type='image' AND type_id=?");
                    $removeAlias->execute(array($imageinfo['id']));
                } else {
                    $setAlias = $dbh->prepare("INSERT INTO aliases (type, type_id, alias) VALUES ('image', ?, ?) ON DUPLICATE KEY UPDATE alias=?");
                    $setAlias->execute(array($imageinfo['id'], $alias, $alias));
                }
            } elseif (isset($_POST['user_alias'])) {
                $alias = trim($_POST['user_alias']);
                if (empty($alias)) {
                    $removeAlias = $dbh->prepare("DELETE FROM aliases WHERE type='user' AND type_id=?");
                    $removeAlias->execute(array($user['uid']));
                } else {
                    $updateUseralias = $dbh->prepare("INSERT INTO aliases (type, type_id, alias) VALUES ('user', ?, ?) ON DUPLICATE KEY UPDATE alias=?");
                    $updateUseralias->execute(array($user['uid'], $alias, $alias));
                }
            }
            header('location: index.php');
        }
        $smarty->assign('profiles', $lobotomy->supported_profiles);
        $smarty->assign('status_list', $lobotomy->getPluginStatus($imageinfo['dbase']));
        $smarty->assign('plugins', $lobotomy->getPluginNames($imageinfo['dbase'], false));
        $smarty->display('image_info.tpl');
    }
}
?>