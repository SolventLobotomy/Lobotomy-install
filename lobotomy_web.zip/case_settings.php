<?php

require('includes/setup.php');
if (!isset($_COOKIE[$config->cookie_name]) || !$auth->checkSession($_COOKIE[$config->cookie_name])) {
    header('Location: login.php');
    exit();
} else {
    $user = $auth->getUser($auth->getSessionUID($_COOKIE[$config->cookie_name]));
}

function isValidMd5($md5 = '') {
    return preg_match('/^[a-f0-9]{32}$/', $md5);
}

$lobotomy = new Lobotomy($dbh, $user['uid']);
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if (isset($_POST['user_alias'])) {
        $alias = trim($_POST['user_alias']);
        if (empty($alias)) {
            $removeAlias = $dbh->prepare("DELETE FROM aliases WHERE type='user' AND type_id=?");
            $removeAlias->execute(array($user['uid']));
        } else {
            $updateUseralias = $dbh->prepare("INSERT INTO aliases (type, type_id, alias) VALUES ('user', ?, ?) ON DUPLICATE KEY UPDATE alias=?");
            $updateUseralias->execute(array($user['uid'], $alias, $alias));
        }
        header('location: case_settings.php');
        exit;
    }
    if (isset($_POST['md5hash']) && isValidMd5($_POST['md5hash'])) {
        if (isset($_POST['comment'])) {
            $comment = $_POST['comment'];
        } else {
            $comment = 'No comment';
        }
        $addHash = $dbh->prepare("INSERT INTO bad_hashes (`md5hash`, `comment`, `added`, `case`) VALUES (?, ?, NOW(), ?)");
        $addHash->execute(array($_POST['md5hash'], $comment, $lobotomy->selection['caseid']));
        header('location: case_settings.php');
        exit;
    }
}
if (isset($_GET['delhash']) && $lobotomy->isValidHashId($_GET['delhash'])) {
    $delHash = $dbh->prepare("DELETE FROM bad_hashes WHERE id=?");
    $delHash->execute(array($_GET['delhash']));
    header('location: case_settings.php');
}
$smarty = new Template();
$smarty->assign('page', 'Case settings');
$smarty->assign('user', $user);
$user_alias = $lobotomy->getAlias('user', $user['uid']);
if ($user_alias) {
    $smarty->assign('user_alias', $user_alias);
}

$smarty->assign('selection', $lobotomy->selection);
$smarty->assign('caseinfo', $lobotomy->getCaseDetails($lobotomy->selection['caseid']));
$smarty->assign('hashes', $lobotomy->getCaseHashes());
$smarty->display('case_settings.tpl');
?>