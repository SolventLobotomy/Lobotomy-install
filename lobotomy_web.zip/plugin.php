<?php

require('includes/setup.php');
ini_set('memory_limit', '-1');
if (!isset($_COOKIE[$config->cookie_name]) || !$auth->checkSession($_COOKIE[$config->cookie_name])) {
    header('Location: login.php');
    exit();
} else {
    $user = $auth->getUser($auth->getSessionUID($_COOKIE[$config->cookie_name]));
}
$lobotomy = new Lobotomy($dbh, $user['uid']);
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if (isset($_POST['user_alias'])) {
        $alias = trim($_POST['user_alias']);
        if (empty($alias)) {
            $removeAlias = $dbh->prepare("DELETE FROM aliases WHERE type='user' AND type_id=?");
            $removeAlias->execute(array($user['uid']));
        } else {
            $updateUseralias = $dbh->prepare("INSERT INTO aliases (type, type_id, alias) VALUES ('user', ?, ?) ON DUPLICATE KEY UPDATE alias=?");
            $updateUseralias->execute(array($user['uid'], $alias, $alias));
        }
    }
    header('location: blank.php');
}
$smarty = new Template();
$smarty->assign('page', 'Plugins');
$smarty->assign('user', $user);
$user_alias = $lobotomy->getAlias('user', $user['uid']);
if ($user_alias) {
    $smarty->assign('user_alias', $user_alias);
}

if (!$lobotomy->selection['imageid']) {
    header('location: index.php');
    exit;
}
$imageinfo = $lobotomy->getImageDetails($lobotomy->selection['imageid']);
$smarty->assign('imageinfo', $imageinfo);
$smarty->assign('dbase', $imageinfo['dbase']);
$smarty->assign('caseinfo', $lobotomy->getCaseDetails($lobotomy->selection['caseid']));
$smarty->assign('selection', $lobotomy->selection);
$smarty->assign('plugins', $lobotomy->getPluginNames($imageinfo['dbase'], false));
if (isset($_GET['name'])) {
    $plugin = $lobotomy->isValidPlugin($imageinfo['dbase'], $_GET['name']);
    if ($plugin) {
        $smarty->assign('plugin', $plugin);
        $smarty->assign('output', $lobotomy->getPluginOutput($imageinfo['dbase'], $plugin));
        $smarty->assign('cs', $lobotomy->getCustomSelections($plugin));
        $smarty->assign('page', $plugin . ' - Plugins');
    } else {
        header('location: index.php');
        exit;
    }
}
$smarty->assign('dbh', $dbh);
$smarty->display('plugin.tpl');
?>
