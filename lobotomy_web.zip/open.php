<?php

require('includes/setup.php');
if (!isset($_COOKIE[$config->cookie_name]) || !$auth->checkSession($_COOKIE[$config->cookie_name])) {
    header('Location: login.php');
    exit();
} else {
    $user = $auth->getUser($auth->getSessionUID($_COOKIE[$config->cookie_name]));
    //Array (4)
    //email
    //password
    //isactive
    //uid
}
$lobotomy = new Lobotomy($dbh, $user['uid']);
if (isset($_GET['type']) && isset($_GET['id'])) {
    switch ($_GET['type']) {
        case 'case':
            if ($_GET['id'] == 0) {
                $lobotomy->selectCase($user['uid'], 0);
                header('location: index.php');
            }
            if ($lobotomy->isValidCase($_GET['id']) && $lobotomy->canAccessCase($user['uid'], $_GET['id'])) {
                $lobotomy->selectCase($user['uid'], $_GET['id']);
            } else {
                header('location: index.php');
            }
            header('location: index.php');
            break;
        case 'image':
            if ($_GET['id'] == 0) {
                $lobotomy->selectImage($user['uid'], 0);
                header('location: index.php');
            }
            if ($lobotomy->isValidImage($_GET['id'])) {
                $currentSelection = $lobotomy->getSelections($user['uid']);
                if ($lobotomy->belongsToCase($_GET['id'], $currentSelection['caseid'])) {
                    $lobotomy->selectImage($user['uid'], $_GET['id']);
                }
                else {
                    header('location: index.php');
                }
            } else {
                header('location: index.php');
            }
            header('location: index.php');
            break;
        default:
            header('location: index.php');
            break;
    }
}
elseif ($_GET['type'] == "reset") {
    $lobotomy->resetSelection($user['uid']);
    header('location: index.php');
}
else {
    header('location: index.php');
}
?>