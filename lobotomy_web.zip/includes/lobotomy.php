<?php
ini_set('display_errors', 'on');
/**
 * Lobotomy methods
 * 
 * These methods are used on various pages of Lobotomy
 * @author Jeroen Hagebeek <iScripters@gmail.com>
 * @version 1.0
 * @package Lobotomy
 */
class Lobotomy {

    /**
     * The PDO database connection object
     * @access private
     * @var object
     */
    private $dbh;
    public $supported_profiles = array(
        'VistaSP0x64',
        'VistaSP0x86',
        'VistaSP1x64',
        'VistaSP1x86',
        'VistaSP2x64',
        'VistaSP2x86',
        'Win2003SP0x86',
        'Win2003SP1x64',
        'Win2003SP1x86',
        'Win2003SP2x64',
        'Win2003SP2x86',
        'Win2008R2SP0x64',
        'Win2008R2SP1x64',
        'Win2008SP1x64',
        'Win2008SP1x86',
        'Win2008SP2x64',
        'Win2008SP2x86',
        'Win2012R2x64',
        'Win2012x64',
        'Win7SP0x64',
        'Win7SP0x86',
        'Win7SP1x64',
        'Win7SP1x86',
        'Win8SP0x64',
        'Win8SP0x86',
        'Win8SP1x64',
        'Win8SP1x86',
        'WinXPSP1x64',
        'WinXPSP2x64',
        'WinXPSP2x86',
        'WinXPSP3x86');
    public $selection = array();

    function __construct($dbh, $uid = 0) {
        $this->dbh = $dbh;
        $this->uid = $uid;
        if ($this->uid > 0) {
            $this->selection = $this->getSelections($this->uid);
        }
    }

    /**
     * Check if the given id is a valid case id and exists in the database
     * @param integer $i 
     * @return boolean
     */
    public function isValidCase($i) {
        $i = intval($i);
        if (!is_int($i)) {
            return false;
        }
        if ($i <= 0) {
            return false;
        }
        $isValidCase = $this->dbh->prepare("SELECT COUNT(*) AS valid FROM cases WHERE id=?");
        $isValidCase->execute(array($i));
        $valid = $isValidCase->fetch(PDO::FETCH_ASSOC);
        if ($valid['valid'] != 1) {
            return false;
        }
        return true;
    }

    /**
     * Check if the given id is a valid image id and exists in the database
     * @param integer $i 
     * @return boolean
     */
    public function isValidImage($i) {
        $i = intval($i);
        if (!is_int($i)) {
            return false;
        }
        if ($i <= 0) {
            return false;
        }
        $isValidCase = $this->dbh->prepare("SELECT COUNT(*) AS valid FROM dumps WHERE id=?");
        $isValidCase->execute(array($i));
        $valid = $isValidCase->fetch(PDO::FETCH_ASSOC);
        if ($valid['valid'] != 1) {
            return false;
        }
        return true;
    }

    /**
     * Check if the given plugin (table) exists for the given database
     * @param string $dbase
     * @param string $plugin
     * @return boolean false or plugin name
     */
    public function isValidPlugin($dbase, $plugin) {
        $name = strtok($plugin, " ");
        $isValid = $this->dbh->prepare("SELECT COUNT(*) AS valid, name FROM " . $dbase . ".plugins WHERE `name`=?");
        $isValid->execute(array($name));
        $plugin = $isValid->fetch(PDO::FETCH_ASSOC);
        if ($plugin['valid']) {
            return $plugin['name'];
        } else {
            return false;
        }
    }

    /**
     * Check if the given image id belongs to the given case id
     * @param integer $image
     * @param integer $case
     * @return boolean
     */
    public function belongsToCase($image, $case) {
        $image = intval($image);
        if (!is_int($image)) {
            return false;
        }
        if ($image <= 0) {
            return false;
        }
        $case = intval($case);
        if (!is_int($case)) {
            return false;
        }
        if ($case <= 0) {
            return false;
        }
        $isValidCase = $this->dbh->prepare("SELECT COUNT(*) AS valid FROM dumps WHERE id=? AND case_assigned=?");
        $isValidCase->execute(array($image, $case));
        $valid = $isValidCase->fetch(PDO::FETCH_ASSOC);
        if ($valid['valid'] != 1) {
            return false;
        }
        return true;
    }

    /**
     * Return an array of the current user's selection (case, image, plugin)
     * @param integer $userid
     * @return array $selection
     */
    public function getSelections($userid) {
        $getSelection = $this->dbh->prepare("SELECT caseid, imageid, pluginname FROM selection WHERE userid=?");
        $getSelection->execute(array($userid));
        $selection = $getSelection->fetchAll();
        if (count($selection) <= 0) {
            $selection[0]['caseid'] = 0;
            $selection[0]['imageid'] = 0;
            $selection[0]['pluginname'] = 0;
        } else {
            if (!$this->isValidCase($selection[0]['caseid'])) {
                $selection[0]['caseid'] = 0;
                $selection[0]['imageid'] = 0;
                $selection[0]['pluginname'] = 0;
            }
            if (!$this->isValidImage($selection[0]['imageid'])) {
                $selection[0]['imageid'] = 0;
                $selection[0]['pluginname'] = 0;
            }
            if (!$this->belongsToCase($selection[0]['imageid'], $selection[0]['caseid'])) {
                $selection[0]['imageid'] = 0;
                $selection[0]['pluginname'] = 0;
            }
        }
        return $selection[0];
    }

    public function getCases($userid) {
        $getCases = $this->dbh->prepare("SELECT id, name FROM cases WHERE ownerid=0 OR ownerid=?");
        $getCases->execute(array($userid));
        $cases1 = $getCases->fetchAll(PDO::FETCH_ASSOC);
        $getCases = $this->dbh->prepare("SELECT caseid AS id, cases.name FROM cases_acl JOIN cases ON cases.id = cases_acl.caseid WHERE userid=?");
        $getCases->execute(array($userid));
        $cases2 = $getCases->fetchAll(PDO::FETCH_ASSOC);
        $cases = array_merge($cases1, $cases2);
        return array_unique($cases, SORT_REGULAR);
    }

    public function canAccessCase($userid, $caseid) {
        $access = 0;
        // Does the user own the case?
        $accessCases = $this->dbh->prepare("SELECT COUNT(*) AS num FROM cases WHERE id=? AND ownerid=?");
        $accessCases->execute(array($caseid, $userid));
        $access1 = $accessCases->fetch(PDO::FETCH_ASSOC);
        $access = $access + $access1['num'];
        // Does the user have read and/or write access on the case?
        $accessCases = $this->dbh->prepare("SELECT COUNT(*) AS num FROM cases_acl WHERE caseid=? AND userid=?");
        $accessCases->execute(array($caseid, $userid));
        $access2 = $accessCases->fetch(PDO::FETCH_ASSOC);
        $access = $access + $access2['num'];
        // Is the case public?
        $accessCases = $this->dbh->prepare("SELECT COUNT(*) AS num FROM cases WHERE id=? AND ownerid=0");
        $accessCases->execute(array($caseid));
        $access3 = $accessCases->fetch(PDO::FETCH_ASSOC);
        $access = $access + $access3['num'];
        return $access;
    }

    public function isCaseOwner($userid, $caseid) {
        $isOwner = $this->dbh->prepare("SELECT COUNT(*) AS owner FROM cases WHERE id=? AND creator=?");
        $isOwner->execute(array($caseid, $userid));
        $is = $isOwner->fetch(PDO::FETCH_ASSOC);
        if ($is['owner']) {
            return true;
        } else {
            return false;
        }
    }

    public function getCaseAccess() {
        $caseAccess = $this->dbh->prepare("SELECT rw FROM cases_acl WHERE caseid=? AND userid=?");
        $caseAccess->execute(array($this->selection['caseid'], $this->uid));
        $perm = $caseAccess->fetch(PDO::FETCH_ASSOC);
        if (count($perm) > 0) {
            return $perm['rw'];
        } else {
            return false;
        }
    }

    public function getCaseHashes() {
        $output = array();
        $caseHashes = $this->dbh->prepare("SELECT `id`, `md5hash`, `added`, `comment` FROM bad_hashes WHERE `case`=?");
        $caseHashes->execute(array($this->selection['caseid']));
        foreach ($caseHashes->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $output[] = $row;
        }
        return $output;
    }

    public function getImages($case = 0) {
        if ($case == 0) {
            $getImages = $this->dbh->prepare("SELECT id, location, dbase, added, case_assigned FROM dumps");
            $getImages->execute();
        } else {
            $getImages = $this->dbh->prepare("SELECT id, location, dbase, added, case_assigned FROM dumps WHERE case_assigned=?");
            $getImages->execute(array($case));
        }
        $images = $getImages->fetchAll(PDO::FETCH_ASSOC);
        return $images;
    }

    public function getCaseDetails($case) {
        $getCaseDetails = $this->dbh->prepare("SELECT id, name, description, creator, added FROM cases WHERE id=?");
        $getCaseDetails->execute(array($case));
        $caseDetails = $getCaseDetails->fetchAll(PDO::FETCH_ASSOC);
        return $caseDetails[0];
    }

    public function getImageDetails($image) {
        $getImageDetails = $this->dbh->prepare("SELECT id, location, dbase, added, case_assigned FROM dumps WHERE id=?");
        $getImageDetails->execute(array($image));
        $imageDetails = $getImageDetails->fetchAll(PDO::FETCH_ASSOC);
        return $imageDetails[0];
    }

    public function getPluginNames($dbase, $showEmpty = true) {
        $getPlugins = $this->dbh->prepare("SELECT name FROM " . $dbase . ".plugins ORDER BY name");
        $getPlugins->execute();
        if ($showEmpty == true) {
            $plugins = $getPlugins->fetchAll(PDO::FETCH_ASSOC);
            return $plugins;
        } else {
            $plugins = array();
            foreach ($getPlugins->fetchAll(PDO::FETCH_ASSOC) as $plugin) {
                $query = "SELECT * FROM " . $dbase . "." . $plugin['name'];
                $isEmpty = $this->dbh->prepare($query);
                $isEmpty->execute();
                if ($isEmpty->rowCount() > 0) {
                    $plugins[] = $plugin;
                }
            }
            return $plugins;
        }
    }

    public function selectCase($user, $case) {
        $selectCase = $this->dbh->prepare("INSERT INTO selection (userid, caseid) VALUES (?, ?) ON DUPLICATE KEY UPDATE caseid=?");
        $selectCase->execute(array($user, $case, $case));
    }

    public function selectImage($user, $image) {
        $selectImage = $this->dbh->prepare("INSERT INTO selection (userid, imageid) VALUES (?, ?) ON DUPLICATE KEY UPDATE imageid=?");
        $selectImage->execute(array($user, $image, $image));
    }

    public function resetSelection($user) {
        $resetSelection = $this->dbh->prepare("DELETE FROM selection WHERE userid=?");
        $resetSelection->execute(array($user));
    }

    public function getImageSettings($dbase) {
        $getSettings = $this->dbh->prepare("SELECT md5hash, initialized, filename, directory, filepath, caseid, profile, description, sha256hash, mtime, atime, ctime FROM " . $dbase . ".settings");
        $getSettings->execute();
        $imageSettings = $getSettings->fetch(PDO::FETCH_ASSOC);
        return $imageSettings;
    }

    public function getAlias($type, $id) {
        $getAlias = $this->dbh->prepare("SELECT COUNT(*) AS alias_exists, alias FROM aliases WHERE type=? AND type_id=?");
        $getAlias->execute(array($type, $id));
        $alias = $getAlias->fetch(PDO::FETCH_ASSOC);
        if ($alias['alias_exists']) {
            return $alias['alias'];
        } else {
            return false;
        }
    }

    public function getPluginStatus($database) {
        $pluginStatus = $this->dbh->prepare("SELECT name, status, started, stopped, pct FROM " . $database . ".plugins ORDER BY name");
        $pluginStatus->execute();
        $status_list = $pluginStatus->fetchAll(PDO::FETCH_ASSOC);
        return $status_list;
    }

    public function getPluginOutput($dbase, $plugin) {
        if ($this->isValidPlugin($dbase, $plugin)) {
            $output = array();
            $query = "DESCRIBE " . $dbase . "." . $plugin;
            $tableColumns = $this->dbh->prepare($query);
            unset($query);
            $tableColumns->execute();
            foreach ($tableColumns->fetchAll(PDO::FETCH_ASSOC) as $table_info) {
                $output['head'][] = $table_info['Field'];
            }
            $fields = '`';
            $fields .= implode('`, `', $output['head']);
            $fields .= '`';
            $query = "SELECT " . $fields . " FROM " . $dbase . "." . $plugin . " ORDER BY id";
            $pluginOutput = $this->dbh->prepare($query);
            $pluginOutput->execute();
            foreach ($pluginOutput->fetchAll(PDO::FETCH_ASSOC) as $table_data) {
                $output['body'][] = $table_data;
            }
            return $output;
        }
    }

    public function searchImageStr($string) {
        $output = array();
        $dbase = $this->getImageDetails($this->selection['imageid'])['dbase'];
        $plugins = $this->getPluginNames($dbase);
        foreach ($plugins as $plugin) {
            $pl = $plugin['name'];
            if ($pl != 'strings' && $pl != 'memtimeliner') {
                $query = "DESCRIBE " . $dbase . "." . $pl;
                $tableColumns = $this->dbh->prepare($query);
                unset($query);
                $tableColumns->execute();
                foreach ($tableColumns->fetchAll(PDO::FETCH_ASSOC) as $table_info) {
                    $output[$pl]['name'] = $pl;
                    $output[$pl]['head'][] = $table_info['Field'];
                }
                $fields = '`';
                $fields .= implode('`, `', $output[$pl]['head']);
                $fields .= '`';
                foreach ($output[$pl]['head'] as $column) {
                    $query = "SELECT " . $fields . " FROM " . $dbase . "." . $pl . " WHERE `" . $column . "` LIKE '%?%'";
                    $pluginOutput = $this->dbh->prepare($query);
                    $pluginOutput->execute(array($string));
                    if ($pluginOutput->rowCount() > 0) {
                        $output[$pl]['body'][] = $pluginOutput->fetchAll(PDO::FETCH_ASSOC);
                    }
                }
            }
        }
        return $output;
    }

    public function searchImagePid($pid) {
        $output = array();
        $dbase = $this->getImageDetails($this->selection['imageid'])['dbase'];
        $plugins = $this->getPluginNames($dbase);
        foreach ($plugins as $plugin) {
            $pl = $plugin['name'];
            if ($pl != 'strings' && $pl != 'memtimeliner') {
                $query = "DESCRIBE " . $dbase . "." . $pl;
                $tableColumns = $this->dbh->prepare($query);
                unset($query);
                $tableColumns->execute();
                foreach ($tableColumns->fetchAll(PDO::FETCH_ASSOC) as $table_info) {
                    $output[$pl]['name'] = $pl;
                    $output[$pl]['head'][] = $table_info['Field'];
                }
                $fields = '`';
                $fields .= implode('`, `', $output[$pl]['head']);
                $fields .= '`';
                if (in_array('pid', $output[$pl]['head'])) {
                    $query = "SELECT " . $fields . " FROM " . $dbase . "." . $pl . " WHERE `pid`=" . $pid;
                    $pluginOutput = $this->dbh->prepare($query);
                    $pluginOutput->execute();
                    if ($pluginOutput->rowCount() > 0) {
                        $output[$pl]['body'][] = $pluginOutput->fetchAll(PDO::FETCH_ASSOC);
                    }
                }
            }
        }
        return $output;
    }

    public function searchStringsStr($string) {
        $output = array();
        $dbase = $this->getImageDetails($this->selection['imageid'])['dbase'];
        $pl = 'strings';
        $query = "DESCRIBE " . $dbase . "." . $pl;
        $tableColumns = $this->dbh->prepare($query);
        unset($query);
        $tableColumns->execute();
        foreach ($tableColumns->fetchAll(PDO::FETCH_ASSOC) as $table_info) {
            $output[$pl]['name'] = $pl;
            $output[$pl]['head'][] = $table_info['Field'];
        }
        $fields = '`';
        $fields .= implode('`, `', $output[$pl]['head']);
        $fields .= '`';
        $query = "SELECT " . $fields . " FROM " . $dbase . "." . $pl . " WHERE `string` LIKE '%" . $string . "%'";
        $pluginOutput = $this->dbh->prepare($query);
        $pluginOutput->execute();
        if ($pluginOutput->rowCount() > 0) {
            $output[$pl]['body'][] = $pluginOutput->fetchAll(PDO::FETCH_ASSOC);
        }
        return $output;
    }

    public function getCustomSelections($plugin) {
        $output = array();
        $dbase = $this->getImageDetails($this->selection['imageid'])['dbase'];
        $customSelections = $this->dbh->prepare("SELECT row_id FROM `" . $dbase . "`.preferences WHERE plugin='" . $plugin . "'");
        $customSelections->execute();
        foreach ($customSelections->fetchAll(PDO::FETCH_ASSOC) as $k => $v) {
            $output[] = $v['row_id'];
        }
        return $output;
    }

    public function getAllCustomSelections() {
        $output = array();
        $dbase = $this->getImageDetails($this->selection['imageid'])['dbase'];
        $selectMarkings = $this->dbh->prepare("SELECT plugin, row_id FROM " . $dbase . ".preferences ORDER BY plugin, row_id");
        $selectMarkings->execute();
        $marked = $selectMarkings->fetchAll(PDO::FETCH_ASSOC);
        foreach ($marked as $row) {
            $pl = $row['plugin'];
            $id = $row['row_id'];
            if ($pl != 'strings' && $pl != 'memtimeliner') {
                $query = "DESCRIBE " . $dbase . "." . $pl;
                $tableColumns = $this->dbh->prepare($query);
                unset($query);
                $tableColumns->execute();
                foreach ($tableColumns->fetchAll(PDO::FETCH_ASSOC) as $table_info) {
                    $output[$pl]['name'] = $pl;
                    $output[$pl]['head'][] = $table_info['Field'];
                    $output[$pl]['head'] = array_unique($output[$pl]['head']);
                }
                $fields = '`';
                $fields .= implode('`, `', $output[$pl]['head']);
                $fields .= '`';
                $query = "SELECT " . $fields . " FROM " . $dbase . "." . $pl . " WHERE `id`=" . $id;
                $pluginOutput = $this->dbh->prepare($query);
                $pluginOutput->execute();
                if ($pluginOutput->rowCount() > 0) {
                    $output[$pl]['body'][] = $pluginOutput->fetchAll(PDO::FETCH_ASSOC);
                }
            }
        }
        return $output;
    }

    public static function checkHash($dbh, $md5, $caseid) {
        $output = array();
        $getHashes = $dbh->prepare("SELECT md5hash, added, `comment` FROM bad_hashes WHERE md5hash=? AND (`case`=0 OR `case`=?)");
        $getHashes->execute(array($md5, $caseid));
        $row = $getHashes->fetchAll();
        if (count($row) <= 0) {
            return false;
        } else {
            $output['added'] = $row[0]['added'];
            $output['msg'] = $row[0]['comment'];
            return $output;
        }
    }

    public function getBadContent($caseid) {
        $output = array();
        $dbase = $this->getImageDetails($this->selection['imageid'])['dbase'];
        $plugins = $this->getPluginNames($dbase);
        foreach ($plugins as $plugin) {
            $pl = $plugin['name'];
            if ($pl != 'strings' && $pl != 'memtimeliner') {
                $query = "DESCRIBE " . $dbase . "." . $pl;
                $tableColumns = $this->dbh->prepare($query);
                unset($query);
                $tableColumns->execute();
                foreach ($tableColumns->fetchAll(PDO::FETCH_ASSOC) as $table_info) {
                    if ($table_info['Field'] != "filename" && $table_info['Field'] != "fullfilename" && $table_info['Field'] != "result") {
                        $output[$pl]['name'] = $pl;
                        $output[$pl]['head'][] = $table_info['Field'];
                    }
                }
                $fields = '`';
                $fields .= implode('`, `', $output[$pl]['head']);
                $fields .= '`';
                if (in_array('md5', $output[$pl]['head'])) {
                    $query = "SELECT " . $fields . " FROM " . $dbase . "." . $pl . " plugin WHERE EXISTS (SELECT `added`, `comment`, `case` FROM lobotomy.`bad_hashes` bh WHERE plugin.md5 = bh.md5hash AND (`case`=0 OR `case`=?))";
                    $pluginOutput = $this->dbh->prepare($query);
                    $pluginOutput->execute(array($caseid));
                    if ($pluginOutput->rowCount() > 0) {
                        $output[$pl]['body'][] = $pluginOutput->fetchAll(PDO::FETCH_ASSOC);
                    }
                }
            }
        }
        return $output;
    }

    public function isValidHashId($hashid) {
        $isValid = $this->dbh->prepare("SELECT COUNT(*) AS valid FROM bad_hashes WHERE id=? AND `case`=?");
        $isValid->execute(array($hashid, $this->selection['caseid']));
        $hash = $isValid->fetch(PDO::FETCH_ASSOC);
        if ($hash['valid']) {
            return true;
        } else {
            return false;
        }
    }
    
    public function getQueue() {
        $imageid = $this->getImageDetails($this->selection['imageid']);
        $image = '%'.$imageid['dbase'].'%';
        $output = array();
        $getQueue = $this->dbh->prepare("SELECT id, command, priority, added FROM queue WHERE command LIKE ? ORDER BY priority");
        $getQueue->execute(array($image));
        foreach ($getQueue->fetchAll(PDO::FETCH_ASSOC) as $item) {
            $output[] = $item;
        }
        return $output;
    }

}

?>
