<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include("/var/www/html/libs/languages/en.php");
include("/var/www/html/libs/config.class.php");
include("/var/www/html/libs/auth.class.php");
include("/var/www/html/includes/database.php");
include("/var/www/html/includes/lobotomy.php");
$config = new Config($dbh);
$auth = new Auth($dbh, $config, $lang);

// load Smarty library
require('/var/www/html/libs/Smarty.class.php');

// The setup.php file is a good place to load
// required application library files, and you
// can do that right here. An example:
// require('guestbook/guestbook.lib.php');

class Template extends SmartyBC {

    function __construct() {

        // Class Constructor.
        // These automatically get set with each new instance.

        parent::__construct();

        define('APP_ROOT', '/var/www/html/');
        $this->setTemplateDir(APP_ROOT . './templates/');
        $this->setCompileDir(APP_ROOT . './templates_c/');
        $this->setConfigDir(APP_ROOT . './configs/');
        $this->setCacheDir(APP_ROOT . './cache/');
        $this->debugging = false;
        $this->clearAllCache();

        //$this->caching = Smarty::CACHING_LIFETIME_CURRENT;
        $this->assign('app_name', 'Lobotomy');
    }

}

?>
